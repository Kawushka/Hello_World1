# 2. С клавиатуры вводится текст, определить, сколько в нём гласных,
# а сколько согласных. В случае равенства вывести на экран все гласные буквы.
# Латинскую букву y считать как согласную.

text = input('Введите текст: ')
glassn = 0
soglasn = 0
list = []
for i in text:
    if i == 'a' or i == 'e' or i == 'i' or i == 'o' or i == 'u' or i == "а" or i == "е" or i == "ё" or i == "и" or i == "о" or i == "у" or i == "ы" or i == "э" or i == "ю" or i == "я":
        glassn += 1
        list.append(i)
    elif i.isdigit():
        continue
    else:
        soglasn += 1
if glassn == soglasn:
    print("Равное кол-во согласных и гласных. Результат:", ''.join(list))
else: print(f'В тексте {text} гласных букв: {glassn}, согласных букв: {soglasn}')
