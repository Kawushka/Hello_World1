# 3. Посчитать, сколько раз встречается определенная цифра в числах.
# Количество введенных чисел и искомая цифра задаются с клавиатуры. Сами числа выбираются рандомно.

from random import randint
schet = 0
a = input('Введите кол-во чисел: ')
b = input('Введите цифру для поиска: ')
spisok = [randint(0,10000) for i in range(int(a))]
print(spisok)
for i in spisok:
    for j in str(i):
        if j == str(b):
            schet += 1
print(schet)
