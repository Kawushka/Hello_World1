# 1. С клавиатуры вводится 7-значное число. Если четных цифр в нем больше, чем нечетных, то найти сумму всех его цифр
# если нечетных больше, то найти произведение 1, 3 и 6 цифры.
chet = 0
nechet = 0
summ = 0
a = str(input('Введите 7-ми значное число: '))
if len(a) == 7:
    for i in a:
        if int(i) % 2 == 0:
            chet += 1
        else:
            nechet += 1
    if nechet > chet:
        print('Произведение: ', int(a[0]) * int(a[2]) * int(a[5]))
    else:
        for i in a:
            summ = summ + int(i)
        print('Сумма: ', summ)
else:
    print('Неверный ввод')
